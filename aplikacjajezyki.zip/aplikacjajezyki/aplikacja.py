

from PyQt5.QtWidgets import QMainWindow, QApplication, QMessageBox, QDialog
from PyQt5.uic import loadUi
from PyQt5 import QtWidgets
import sys

jezyk = "pl"



class Start(QMainWindow):
    def __init__(self):
        super(Start, self).__init__()
        global jezyk
        print(jezyk)
        if(jezyk == "pl"):
            loadUi("Start.ui", self)
        else:
            loadUi("StartEN.ui", self)
        
        self.pushButton.clicked.connect(self.gotoSettings)
        self.pushButton_4.clicked.connect(self.gotoCredits)
        self.pushButton_2.clicked.connect(self.gotoSkrzyzowania)
        self.pushButton_3.clicked.connect(self.gotoHistoria)
        
    def gotoSettings(self):
        widget.setCurrentIndex(widget.currentIndex()+1)

    def gotoCredits(self):
        widget.setCurrentIndex(widget.currentIndex()+2)

    def gotoSkrzyzowania(self):
        widget.setCurrentIndex(widget.currentIndex()+3)

    def gotoHistoria(self):
        widget.setCurrentIndex(widget.currentIndex()+4)


class Jezyk(QMainWindow):
    def __init__(self):
        super(Jezyk, self).__init__()
        loadUi("Jezyk.ui", self)
        
        self.pushButton.clicked.connect(self.changeLanguage1)
        self.pushButton_2.clicked.connect(self.changeLanguage2)
        
    def changeLanguage1(self):
        global jezyk
        jezyk = "pl"
        start = Start()
        settings = Settings()
        credits = Credits()
        skrzyzowania = Skrzyzowania()
        historia = Historia()
        s1 = S1()
        s2 = S2()
        s3 = S3()
        b1 = B1()
        b2 = B2()
        b3 = B3()
        widget.addWidget(start)
        widget.addWidget(settings)
        widget.addWidget(credits)
        widget.addWidget(skrzyzowania)
        widget.addWidget(historia)
        widget.addWidget(s1)
        widget.addWidget(s2)
        widget.addWidget(s3)
        widget.addWidget(b1)
        widget.addWidget(b2)
        widget.addWidget(b3)
        widget.setCurrentIndex(widget.currentIndex()+1)

    
    def changeLanguage2(self):
        global jezyk
        jezyk = "en"
        start = Start()
        settings = Settings()
        credits = Credits()
        skrzyzowania = Skrzyzowania()
        historia = Historia()
        s1 = S1()
        s2 = S2()
        s3 = S3()
        b1 = B1()
        b2 = B2()
        b3 = B3()
        widget.addWidget(start)
        widget.addWidget(settings)
        widget.addWidget(credits)
        widget.addWidget(skrzyzowania)
        widget.addWidget(historia)
        widget.addWidget(s1)
        widget.addWidget(s2)
        widget.addWidget(s3)
        widget.addWidget(b1)
        widget.addWidget(b2)
        widget.addWidget(b3)
        widget.setCurrentIndex(widget.currentIndex()+1)
        



class Credits(QMainWindow):
    def __init__(self):
        super(Credits, self).__init__()
        global jezyk
        if(jezyk == "pl"):
            loadUi("Credits.ui", self)
        else:
            loadUi("CreditsEN.ui", self)
        
        self.pushButton_4.clicked.connect(self.gotoCancel)
        
    def gotoCancel(self):

        widget.setCurrentIndex(widget.currentIndex()-2)

class Historia(QMainWindow):
    def __init__(self):
        super(Historia, self).__init__()
        global jezyk
        if(jezyk == "pl"):
            loadUi("Historia_symulacji.ui", self)
        else:
            loadUi("Historia_symulacjiEN.ui", self)
        
        self.pushButton_4.clicked.connect(self.gotoCancel)
        
    def gotoCancel(self):

        widget.setCurrentIndex(widget.currentIndex()-4)

class Skrzyzowania(QMainWindow):
    def __init__(self):
        super(Skrzyzowania, self).__init__()
        global jezyk
        if(jezyk == "pl"):
            loadUi("Skrzyzowania.ui", self)
        else:
            loadUi("SkrzyzowaniaEN.ui", self)
        
        self.pushButton_4.clicked.connect(self.gotoCancel)
        self.pushButton.clicked.connect(self.gotoS1)
        self.pushButton_2.clicked.connect(self.gotoS2)
        self.pushButton_3.clicked.connect(self.gotoS3)
        
    def gotoCancel(self):

        widget.setCurrentIndex(widget.currentIndex()-3)

    def gotoS1(self):

        widget.setCurrentIndex(widget.currentIndex()+2)

    def gotoS2(self):

        widget.setCurrentIndex(widget.currentIndex()+3)

    def gotoS3(self):

        widget.setCurrentIndex(widget.currentIndex()+4)

class Settings(QMainWindow):
    def __init__(self):
        super(Settings, self).__init__()
        global jezyk
        if(jezyk == "pl"):
            loadUi("Ustawienia.ui", self)
        else:
            loadUi("UstawieniaEN.ui", self)

        self.pushButton_5.clicked.connect(self.gotoZatwierdz)
        self.pushButton_4.clicked.connect(self.gotoCancel)
    
    def gotoZatwierdz(self):
        if(self.listWidget.currentRow() == 0):
            widget.setFixedHeight(1080)
            widget.setFixedWidth(1920)
            widget.setCurrentIndex(widget.currentIndex()-1)

        if(self.listWidget.currentRow() == 1):
            widget.setFixedHeight(900)
            widget.setFixedWidth(1600)
            widget.setCurrentIndex(widget.currentIndex()-1)

        if(self.listWidget.currentRow() == 2):
            widget.setFixedHeight(900)
            widget.setFixedWidth(1440)
            widget.setCurrentIndex(widget.currentIndex()-1)

        if(self.listWidget.currentRow() == 3):
            widget.setFixedHeight(700)
            widget.setFixedWidth(1280)
            widget.setCurrentIndex(widget.currentIndex()-1)

        if(self.listWidget.currentRow() == 4):
            widget.setFixedHeight(600)
            widget.setFixedWidth(800)
            widget.setCurrentIndex(widget.currentIndex()-1)

        
    
    def gotoCancel(self):

        widget.setCurrentIndex(widget.currentIndex()-1)

class S1(QMainWindow):
    def __init__(self):
        super(S1, self).__init__()
        global jezyk
        if(jezyk == "pl"):
            loadUi("skrzyzowanie1A.ui", self)
        else:
            loadUi("skrzyzowanie1AEN.ui", self)
        
        self.pushButton_4.clicked.connect(self.gotoCancel)
        self.pushButton_6.clicked.connect(self.Plus)
        self.pushButton_7.clicked.connect(self.Minus)
        self.pushButton_5.clicked.connect(self.gotoB1)
        
    def gotoCancel(self):

        widget.setCurrentIndex(widget.currentIndex()-2)

    def Plus(self):

        if(int(self.label_5.text()) < 10):
            self.label_5.setText(str(int(self.label_5.text()) + 1))

    def Minus(self):

        if(int(self.label_5.text()) > 0):
            self.label_5.setText(str(int(self.label_5.text()) - 1))

    def gotoB1(self):

        widget.setCurrentIndex(widget.currentIndex()+3)

class B1(QMainWindow):
    def __init__(self):
        super(B1, self).__init__()
        global jezyk
        if(jezyk == "pl"):
            loadUi("skrzyzowanie1B.ui", self)
        else:
            loadUi("skrzyzowanie1BEN.ui", self)
        
        self.pushButton_4.clicked.connect(self.gotoCancel)
        
    def gotoCancel(self):

        widget.setCurrentIndex(widget.currentIndex()-5)

class S2(QMainWindow):
    def __init__(self):
        super(S2, self).__init__()
        global jezyk
        if(jezyk == "pl"):
            loadUi("skrzyzowanie2A.ui", self)
        else:
            loadUi("skrzyzowanie2AEN.ui", self)
        
        self.pushButton_4.clicked.connect(self.gotoCancel)
        self.pushButton_6.clicked.connect(self.Plus)
        self.pushButton_7.clicked.connect(self.Minus)
        self.pushButton_5.clicked.connect(self.gotoB2)
        
    def gotoCancel(self):

        widget.setCurrentIndex(widget.currentIndex()-3)

    def Plus(self):

        if(int(self.label_5.text()) < 10):
            self.label_5.setText(str(int(self.label_5.text()) + 1))

    def Minus(self):

        if(int(self.label_5.text()) > 0):
            self.label_5.setText(str(int(self.label_5.text()) - 1))

    def gotoB2(self):

        widget.setCurrentIndex(widget.currentIndex()+3)

class B2(QMainWindow):
    def __init__(self):
        super(B2, self).__init__()
        global jezyk
        if(jezyk == "pl"):
            loadUi("skrzyzowanie2B.ui", self)
        else:
            loadUi("skrzyzowanie2BEN.ui", self)
        
        self.pushButton_4.clicked.connect(self.gotoCancel)
        
    def gotoCancel(self):

        widget.setCurrentIndex(widget.currentIndex()-6)

class S3(QMainWindow):
    def __init__(self):
        super(S3, self).__init__()
        global jezyk
        if(jezyk == "pl"):
            loadUi("skrzyzowanie3A.ui", self)
        else:
            loadUi("skrzyzowanie3AEN.ui", self)
        
        self.pushButton_4.clicked.connect(self.gotoCancel)
        self.pushButton_6.clicked.connect(self.Plus)
        self.pushButton_7.clicked.connect(self.Minus)
        self.pushButton_5.clicked.connect(self.gotoB3)
        
    def gotoCancel(self):

        widget.setCurrentIndex(widget.currentIndex()-4)

    def Plus(self):

        if(int(self.label_5.text()) < 10):
            self.label_5.setText(str(int(self.label_5.text()) + 1))

    def Minus(self):

        if(int(self.label_5.text()) > 0):
            self.label_5.setText(str(int(self.label_5.text()) - 1))

    def gotoB3(self):

        widget.setCurrentIndex(widget.currentIndex()+3)

class B3(QMainWindow):
    def __init__(self):
        super(B3, self).__init__()
        loadUi("skrzyzowanie1B.ui", self)
        global jezyk
        if(jezyk == "pl"):
            loadUi("skrzyzowanie1B.ui", self)
        else:
            loadUi("skrzyzowanie1BEN.ui", self)
        
        self.pushButton_4.clicked.connect(self.gotoCancel)
        
    def gotoCancel(self):

        widget.setCurrentIndex(widget.currentIndex()-7)

    



app = QApplication(sys.argv)
widget = QtWidgets.QStackedWidget()
jezyk = Jezyk()

widget.addWidget(jezyk)

widget.setFixedHeight(600)
widget.setFixedWidth(800)
widget.show()

try:
    sys.exit(app.exec_())
except:
    print("Exiting")


#if __name__ == '__main__':
#    app = QApplication(sys.argv)
#    start = Start()
#    settings = Settings()
#    widget = QtWidgets.QStackedWidget()
#    app.exec_()
#    widget.addWidget(start)
#    widget.addWidget(settings)
#    widget.show()
